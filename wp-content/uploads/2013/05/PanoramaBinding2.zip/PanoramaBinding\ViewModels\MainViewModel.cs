﻿using System;
using System.Collections.Generic;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using Windows.ApplicationModel;
using Windows.Storage;

namespace PanoramaBinding.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private string backgroundPath;

        public string BackgroundPath
        {
            get { return backgroundPath; }
            set
            {
                backgroundPath = value;
                RaisePropertyChanged(() => BackgroundPath);
            }
        }

        public MainViewModel()
        {
            //BackgroundPath = "http://4.bp.blogspot.com/-m0CqTN988_U/USd9rxvPikI/AAAAAAAADDY/4JKRsm3cD8c/s1600/free-wallpaper-downloads.jpg";
        }

        public RelayCommand LoadImages
        {
            get
            {
                return new RelayCommand(async () =>
                    {
                        StorageFolder folder = await Package.Current.InstalledLocation.GetFolderAsync("Assets\\Images\\");
                        IReadOnlyList<StorageFile> files = await folder.GetFilesAsync();
                        foreach (StorageFile file in files)
                        {
                            await file.CopyAsync(ApplicationData.Current.LocalFolder, file.Name, NameCollisionOption.ReplaceExisting);
                        }

                        BackgroundPath = "isostore://Balls.jpg";
                    });
            }
        }
    }
}
