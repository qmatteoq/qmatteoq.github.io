﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Caliburn.Micro;
using CaliburnMicro.Messages;

namespace CaliburnMicro.ViewModels
{
    public class SecondPageViewModel: Screen
    {
        private readonly IEventAggregator eventAggregator;

        public SecondPageViewModel(IEventAggregator eventAggregator)
        {
            this.eventAggregator = eventAggregator;
        }

        public void SendMessage()
        {
            eventAggregator.Publish(new SampleMessage("Matteo"));
        }
    }
}
