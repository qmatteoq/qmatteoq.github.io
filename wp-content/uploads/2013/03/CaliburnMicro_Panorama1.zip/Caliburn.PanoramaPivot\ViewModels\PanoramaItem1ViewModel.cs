﻿using Caliburn.Micro;

namespace Caliburn.PanoramaPivot.ViewModels
{
    public class PanoramaItem1ViewModel: Screen
    {
        public PanoramaItem1ViewModel()
        {
            DisplayName = "Panorama 1";
        }
    }
}
