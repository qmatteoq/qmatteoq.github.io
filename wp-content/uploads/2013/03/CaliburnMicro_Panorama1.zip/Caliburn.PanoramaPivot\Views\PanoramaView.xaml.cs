﻿using Microsoft.Phone.Controls;

namespace Caliburn.PanoramaPivot.Views
{
    public partial class PanoramaView : PhoneApplicationPage
    {
        public PanoramaView()
        {
            InitializeComponent();
        }
    }
}