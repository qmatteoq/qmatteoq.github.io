﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Caliburn.Micro;

namespace Caliburn.PanoramaPivot.ViewModels
{
    public class PivotItem1ViewModel: Screen
    {
        public PivotItem1ViewModel()
        {
            DisplayName = "First pivot";
        }
    }
}
