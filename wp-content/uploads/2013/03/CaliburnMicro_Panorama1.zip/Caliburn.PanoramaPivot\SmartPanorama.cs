﻿using System;
using System.Windows;
using System.Windows.Media;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Controls.Primitives;

namespace Caliburn.PanoramaPivot
{
    public class SmartPanorama : Panorama
   {
      private PanningLayer backgroundLayer;
      private PanningLayer titleLayer;
      private PanningLayer itemsLayer;
      private int? initialIndex;
      private int frameCount;

      /// <summary>
      /// An revised version of original panorama control
      /// </summary>
      public SmartPanorama()
      {
         CompositionTarget.Rendering += this.OnRendering;
      }

      /// <summary>
      /// Retrieves panning layer from template
      /// </summary>
      public override void OnApplyTemplate()
      {
         base.OnApplyTemplate();
         this.backgroundLayer = this.GetTemplateChild("BackgroundLayer") as PanningLayer;
         this.titleLayer = this.GetTemplateChild("TitleLayer") as PanningLayer;
         this.itemsLayer = this.GetTemplateChild("ItemsLayer") as PanningLayer;
      }

      #region InitialIndex

      /// <summary>
      /// InitialIndex Dependency Property
      /// </summary>
      public static readonly DependencyProperty InitialIndexProperty =
          DependencyProperty.Register("InitialIndex", typeof(int), typeof(SmartPanorama),
              new PropertyMetadata(0, new PropertyChangedCallback(OnInitialIndexChanged)));

      /// <summary>
      /// Gets or sets the InitialIndex property. This dependency property 
      /// indicates ....
      /// </summary>
      public int InitialIndex
      {
         get { return (int)GetValue(InitialIndexProperty); }
         set { SetValue(InitialIndexProperty, value); }
      }

      /// <summary>
      /// Handles changes to the InitialIndex property.
      /// </summary>
      private static void OnInitialIndexChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
      {
         SmartPanorama target = (SmartPanorama)d;
         int oldValue = (int)e.OldValue;
         int newValue = target.InitialIndex;
         target.OnInitialIndexChanged(oldValue, newValue);
      }

      /// <summary>
      /// Provides derived classes an opportunity to handle changes to the InitialIndex property.
      /// </summary>
      protected virtual void OnInitialIndexChanged(int oldValue, int newValue)
      {
         if (this.backgroundLayer != null && this.titleLayer != null && this.itemsLayer != null)
         {
            this.Select(newValue);
         }
         else
         {
            this.initialIndex = newValue;
         }
      }

      #endregion

      /// <summary>
      /// Set initial item
      /// </summary>
      /// <param name="itemIndex">Index of the item to selecte</param>
      public void Select(int itemIndex)
      {
         if (itemIndex >= 0 && itemIndex <= this.Items.Count)
         {
            if (this.Items.Count > 0)
            {

               System.Diagnostics.Debug.WriteLine("Back:{0}", this.backgroundLayer.ActualWidth);
               System.Diagnostics.Debug.WriteLine("Tit:{0}", this.titleLayer.ActualWidth);
               System.Diagnostics.Debug.WriteLine("Item:{0}", this.itemsLayer.ActualWidth);

               //Fooling SelectedItem being read-only :-)
               PanoramaItem item = this.Items[itemIndex] as PanoramaItem;
               this.SetValue(SelectedItemProperty, item);

               double itemWidth = (this.Items[0] as PanoramaItem).ActualWidth;
               double itemsOffset = itemIndex == this.Items.Count - 1 ? itemWidth : -itemWidth * itemIndex;
               double layerOffset;
               if (this.itemsLayer.ActualWidth < this.backgroundLayer.ActualWidth)
                  layerOffset = itemIndex == this.Items.Count - 1 ? this.backgroundLayer.ActualWidth - itemWidth : -itemWidth * itemIndex;
               else
                  layerOffset = -itemWidth * itemIndex; ;
               if (this.backgroundLayer != null) this.backgroundLayer.GoTo((int)layerOffset, TimeSpan.FromSeconds(0));
               if (this.titleLayer != null) this.titleLayer.GoTo((int)layerOffset, TimeSpan.FromSeconds(0));
               if (this.itemsLayer != null) this.itemsLayer.GoTo((int)itemsOffset, TimeSpan.FromSeconds(0));
            }
         }
      }

      /// <summary>
      /// Allows panorama to complete initial animation before setting optional initial item
      /// </summary>
      /// <param name="sender">Event sender</param>
      /// <param name="e">Event argument</param>
      private void OnRendering(object sender, EventArgs e)
      {
         if (this.frameCount++ == 3)
         {
            CompositionTarget.Rendering -= new EventHandler(this.OnRendering);
            if (this.initialIndex != null)
            {
               this.Select(this.initialIndex.Value);
               this.initialIndex = null;
            }
         }
      }
   }
}
