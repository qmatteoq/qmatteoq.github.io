﻿using Caliburn.Micro;

namespace Caliburn.PanoramaPivot.ViewModels
{
    public class PanoramaItem2ViewModel: Screen
    {
        public PanoramaItem2ViewModel()
        {
            DisplayName = "Panorama 2";
        }
    }
}
