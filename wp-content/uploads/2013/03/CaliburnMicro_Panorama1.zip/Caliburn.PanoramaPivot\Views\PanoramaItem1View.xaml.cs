﻿using Microsoft.Phone.Controls;

namespace Caliburn.PanoramaPivot.Views
{
    public partial class PanoramaItem1View : PhoneApplicationPage
    {
        public PanoramaItem1View()
        {
            InitializeComponent();
        }
    }
}