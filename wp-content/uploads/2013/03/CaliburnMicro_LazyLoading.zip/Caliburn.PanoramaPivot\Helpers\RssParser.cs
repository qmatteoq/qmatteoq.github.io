﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using Caliburn.PanoramaPivot.Entities;

namespace Caliburn.PanoramaPivot.Helpers
{
    public static class RssParser
    {
        public static IEnumerable<FeedItem> ParseXml(string content)
        {
            XDocument doc = XDocument.Parse(content);
            var result = doc.Descendants("rss").Descendants("channel").Elements("item").Select(x => new FeedItem
                                                                    {
                                                                        Title = x.Element("title").Value,
                                                                        Description = x.Element("description").Value
                                                                    });

            return result;
        }
    }
}
