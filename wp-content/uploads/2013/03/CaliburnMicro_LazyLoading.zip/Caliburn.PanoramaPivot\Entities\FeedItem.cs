﻿using System;

namespace Caliburn.PanoramaPivot.Entities
{
    public class FeedItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
    }
}
