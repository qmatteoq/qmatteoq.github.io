﻿using Microsoft.Phone.Controls;

namespace Caliburn.PanoramaPivot.Views
{
    public partial class PanoramaItem2View : PhoneApplicationPage
    {
        public PanoramaItem2View()
        {
            InitializeComponent();
        }
    }
}