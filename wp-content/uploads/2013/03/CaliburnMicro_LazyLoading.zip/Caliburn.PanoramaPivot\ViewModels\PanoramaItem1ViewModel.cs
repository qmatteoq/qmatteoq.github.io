﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using Caliburn.Micro;
using Caliburn.PanoramaPivot.Entities;
using Caliburn.PanoramaPivot.Helpers;

namespace Caliburn.PanoramaPivot.ViewModels
{
    public class PanoramaItem1ViewModel: Screen
    {
        public PanoramaItem1ViewModel()
        {
            DisplayName = "Panorama 1";
        }

        protected override async void OnActivate()
        {
            base.OnActivate();
            WebClient client = new WebClient();
            string result = await client.DownloadStringTaskAsync("http://feeds.feedburner.com/qmatteoq_eng");
            IEnumerable<FeedItem> feedItems = RssParser.ParseXml(result);

            FeedItems = feedItems.ToList();
        }

        private List<FeedItem> _feedItems;

        public List<FeedItem> FeedItems
        {
            get { return _feedItems; }
            set
            {
                _feedItems = value;
                NotifyOfPropertyChange(() => FeedItems);
            }
        } 
    }
}
