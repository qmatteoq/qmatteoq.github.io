﻿using Caliburn.Micro;

namespace Caliburn.PanoramaPivot.ViewModels
{
    public class PanoramaViewModel : Conductor<IScreen>.Collection.OneActive
    {
        private readonly PanoramaItem1ViewModel item1;
        private readonly PanoramaItem2ViewModel item2;

        public PanoramaViewModel(PanoramaItem1ViewModel item1, PanoramaItem2ViewModel item2)
        {
            this.item1 = item1;
            this.item2 = item2;
        }

        protected override void OnInitialize()
        {
            base.OnInitialize();

            Items.Add(item1);
            Items.Add(item2);

            ActivateItem(item1);
        }
    }
}
