﻿using System.Windows.Input;
using Microsoft.Phone.Controls;

namespace Caliburn.FastAppResume.Views
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }
    }
}