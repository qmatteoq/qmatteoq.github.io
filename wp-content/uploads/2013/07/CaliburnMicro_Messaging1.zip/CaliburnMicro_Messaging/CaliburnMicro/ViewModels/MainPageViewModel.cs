﻿using System;
using System.Diagnostics;
using Caliburn.Micro;
using CaliburnMicro.Messages;
using Microsoft.Phone.Shell;

namespace CaliburnMicro.ViewModels
{
    public class MainPageViewModel: Screen, IHandle<SampleMessage>
    {
        private readonly IEventAggregator eventAggregator;
        private readonly INavigationService navigationService;
        private string name;

        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                NotifyOfPropertyChange(() => Name);
            }
        }

        public MainPageViewModel(IEventAggregator eventAggregator, INavigationService navigationService)
        {
            this.eventAggregator = eventAggregator;
            this.navigationService = navigationService;

            eventAggregator.Subscribe(this);
        }

        public void GoToPage2()
        {
            navigationService.UriFor<SecondPageViewModel>().Navigate();
        }

     
        public void Handle(SampleMessage message)
        {
            Name = message.Name;
        }
    }
}
