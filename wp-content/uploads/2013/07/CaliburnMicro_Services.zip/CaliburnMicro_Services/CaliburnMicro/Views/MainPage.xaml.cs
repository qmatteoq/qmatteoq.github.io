﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using Caliburn.Micro;
using CaliburnMicro.Messages;
using Microsoft.Phone.Controls;

namespace CaliburnMicro.Views
{
    public partial class MainPage : PhoneApplicationPage, IHandle<SampleMessage>
    {
        private IEventAggregator eventAggregator;

        // Constructor
        public MainPage()
        {
            InitializeComponent();

            Bootstrapper bootstrapper = Application.Current.Resources["bootstrapper"] as Bootstrapper;

            IEventAggregator eventAggregator =
                bootstrapper.container.GetAllInstances(typeof (IEventAggregator)).FirstOrDefault() as IEventAggregator;

            this.eventAggregator = eventAggregator;

            eventAggregator.Subscribe(this);
        }

        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}
        public void Handle(SampleMessage message)
        {
            MessageBox.Show(message.Name);
        }

        private void OnSendOtherMessageClicked(object sender, RoutedEventArgs e)
        {
            eventAggregator.Publish(new SampleMessage("Matteo"));
        }
    }
}