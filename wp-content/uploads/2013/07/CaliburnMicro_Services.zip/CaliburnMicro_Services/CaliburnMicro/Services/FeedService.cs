﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using CaliburnMicro.Entities;

namespace CaliburnMicro.Services
{
    public class FeedService: IFeedService
    {
        public async Task<List<FeedItem>> GetNews(string url)
        {
            WebClient client = new WebClient();
            string content = await client.DownloadStringTaskAsync(url);

            XDocument doc = XDocument.Parse(content);
            var result = doc.Descendants("rss").Descendants("channel").Elements("item").Select(x => new FeedItem
            {
                Title = x.Element("title").Value,
                Description = x.Element("description").Value
            }).ToList();

            return result;
        }
    }
}
