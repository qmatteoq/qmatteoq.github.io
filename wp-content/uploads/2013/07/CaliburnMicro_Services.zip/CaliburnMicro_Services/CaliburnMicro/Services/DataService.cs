﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CaliburnMicro.Entities;

namespace CaliburnMicro.Services
{
    public class DataService
    {
        public FeedItem SelectedItem { get; set; }
    }
}
