﻿using System.Collections.Generic;
using System.Windows;
using Caliburn.Micro;
using CaliburnMicro.Entities;
using CaliburnMicro.Messages;
using CaliburnMicro.Services;
using Microsoft.Phone.Tasks;

namespace CaliburnMicro.ViewModels
{
    public class MainPageViewModel: Screen
    {
        private readonly IFeedService feedService;
        private readonly INavigationService navigationService;
        private readonly DataService dataService;

        private List<FeedItem> news;

        public List<FeedItem> News
        {
            get { return news; }
            set
            {
                news = value;
                NotifyOfPropertyChange(() => News);
            }
        }

        private FeedItem selectedNew;

        public FeedItem SelectedNew
        {
            get { return selectedNew; }
            set
            {
                selectedNew = value;
                dataService.SelectedItem = value;
                navigationService.UriFor<DetailPageViewModel>().Navigate();
                NotifyOfPropertyChange(() => SelectedNew);
            }
        }

        public MainPageViewModel(IFeedService feedService, INavigationService navigationService, DataService dataService)
        {
            this.feedService = feedService;
            this.navigationService = navigationService;
            this.dataService = dataService;
        }

        public async void LoadWebsite()
        {
            News = await feedService.GetNews("http://feeds.feedburner.com/qmatteoq_eng");
        }
    }
}
