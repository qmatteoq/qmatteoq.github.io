﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Caliburn.Micro;
using CaliburnMicro.Services;

namespace CaliburnMicro.ViewModels
{
    public class DetailPageViewModel: Screen
    {
        private string title;

        public string Title
        {
            get { return title; }
            set
            {
                title = value;
                NotifyOfPropertyChange(() => Title);
            }
        }

        private string description;

        public string Description
        {
            get { return description; }
            set
            {
                description = value;
                NotifyOfPropertyChange(() => Description);
            }
        }


        public DetailPageViewModel(DataService dataService)
        {
            Title = dataService.SelectedItem.Title;
            Description = dataService.SelectedItem.Description;
        }
    }
}
