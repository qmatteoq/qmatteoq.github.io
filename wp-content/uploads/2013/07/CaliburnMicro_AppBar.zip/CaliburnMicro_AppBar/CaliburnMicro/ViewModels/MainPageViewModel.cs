﻿using System;
using System.Windows;
using Caliburn.Micro;

namespace CaliburnMicro.ViewModels
{
    public class MainPageViewModel: Screen
    {
        private string addItemText;

        public string AddItemText
        {
            get { return addItemText; }
            set
            {
                addItemText = value;
                NotifyOfPropertyChange(() => AddItemText);
            }
        }

        private Uri icon;

        public Uri Icon
        {
            get { return icon; }
            set
            {
                icon = value;
                NotifyOfPropertyChange(() => Icon);
            }
        }

        private bool isVisible;

        public bool IsVisible
        {
            get { return isVisible; }
            set
            {
                isVisible = value;
                NotifyOfPropertyChange(() => IsVisible);
            }
        }

        public MainPageViewModel()
        {
            AddItemText = "Add";
            Icon = new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative);
            IsVisible = false;  
        }

        public void AddItem()
        {
            MessageBox.Show("Item added");
        }

        public void RemoveItem()
        {
            MessageBox.Show("Item removed");
        }
    }
}
