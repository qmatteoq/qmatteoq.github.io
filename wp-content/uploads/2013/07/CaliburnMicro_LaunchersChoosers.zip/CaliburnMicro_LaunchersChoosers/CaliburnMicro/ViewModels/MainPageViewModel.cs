﻿using System.Windows;
using Caliburn.Micro;
using Microsoft.Phone.Tasks;

namespace CaliburnMicro.ViewModels
{
    public class MainPageViewModel: Screen, IHandle<TaskCompleted<PhoneNumberResult>>
    {
        private readonly IEventAggregator eventAggregator;

        public MainPageViewModel(IEventAggregator eventAggregator)
        {
            this.eventAggregator = eventAggregator;

            eventAggregator.Subscribe(this);
        }

        public void LaunchMap()
        {
            eventAggregator.RequestTask<MapsTask>(task =>
                                                      {
                                                          task.SearchTerm = "Milan";
                                                      });
        }

        protected override void OnActivate()
        {
            eventAggregator.Subscribe(this);
            base.OnActivate();
        }

        protected override void OnDeactivate(bool close)
        {
            eventAggregator.Unsubscribe(this);
            base.OnDeactivate(close);
        }

        public void OpenContact()
        {
            eventAggregator.RequestTask<PhoneNumberChooserTask>();
        }

        public void Handle(TaskCompleted<PhoneNumberResult> message)
        {
            MessageBox.Show(message.Result.DisplayName);
        }
    }
}
