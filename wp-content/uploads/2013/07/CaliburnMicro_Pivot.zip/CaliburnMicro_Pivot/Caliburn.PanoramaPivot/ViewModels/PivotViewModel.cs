﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Caliburn.Micro;

namespace Caliburn.PanoramaPivot.ViewModels
{
    public class PivotViewModel: Conductor<IScreen>.Collection.OneActive
    {
        private readonly PivotItem1ViewModel item1;
        private readonly PivotItem2ViewModel item2;

        public PivotViewModel(PivotItem1ViewModel item1, PivotItem2ViewModel item2)
        {
            this.item1 = item1;
            this.item2 = item2;
        }

        protected override void OnInitialize()
        {
            base.OnInitialize();

            Items.Add(item1);
            Items.Add(item2);

            ActivateItem(item1);
        }
    }
}
