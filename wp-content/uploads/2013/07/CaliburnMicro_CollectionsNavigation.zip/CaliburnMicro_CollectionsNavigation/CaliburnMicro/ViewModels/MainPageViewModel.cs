﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Caliburn.Micro;

namespace CaliburnMicro.ViewModels
{
    public class MainPageViewModel: PropertyChangedBase
    {
        private readonly INavigationService navigationService;

        public MainPageViewModel(INavigationService navigationService)
        {
            this.navigationService = navigationService;
        }



        private bool isEnabled;

        public bool IsEnabled
        {
            get { return isEnabled; }
            set
            {
                isEnabled = value;
                NotifyOfPropertyChange(() => IsEnabled);
                NotifyOfPropertyChange(() => CanShowName);
            }
        }

        public bool CanShowName
        {
            get { return IsEnabled; }
        }

        public void ShowName()
        {
            MessageBox.Show("Clicked");
        }

        private ObservableCollection<string> items;

        public ObservableCollection<string> Items
        {
            get { return items; }
            set
            {
                items = value;
                NotifyOfPropertyChange(() => Items);
            }

        }

        private string selectedItem;

        public string SelectedItem
        {
            get { return selectedItem; }
            set
            {
                selectedItem = value;
                NotifyOfPropertyChange(() => SelectedItem);
                MessageBox.Show(value);
            }
        }

        public void GoToPage2()
        {
            navigationService.UriFor<Page2ViewModel>()
                             .WithParam(x => x.Name, "Matteo")
                             .Navigate();
        }

    }
}
