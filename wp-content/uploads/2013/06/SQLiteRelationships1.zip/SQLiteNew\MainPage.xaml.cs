﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;
using SQLiteWinRTPhone;
using Windows.Storage;

namespace SQLiteNew
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }
      
        private async void OnCreateDatabaseClicked(object sender, RoutedEventArgs e)
        {
            Database database = new Database(ApplicationData.Current.LocalFolder, "people.db");

            await database.OpenAsync();

            string query = "CREATE TABLE PEOPLE " +
                           "(Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                           "Name varchar(100), " +
                           "Surname varchar(100))";

            await database.ExecuteStatementAsync(query);
                string query2 = "CREATE TABLE ORDERS " +
                                "(Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                                "Description VARCHAR(200)," +
                                "Amount INTEGER," +
                                "PersonId INTEGER, " +
                                "FOREIGN KEY(PersonId) REFERENCES People(Id) ON DELETE CASCADE)";

                await database.ExecuteStatementAsync(query2);
        }

        private async void OnAddDataClicked(object sender, RoutedEventArgs e)
        {
            Database database = new Database(ApplicationData.Current.LocalFolder, "people.db");

            await database.OpenAsync();

            string query = "INSERT INTO PEOPLE (Name, Surname) VALUES (@name, @surname)";
            Statement statement = await database.PrepareStatementAsync(query);
            statement.BindTextParameterWithName("@name", "Matteo");
            statement.BindTextParameterWithName("@surname", "Pagani");

            await statement.StepAsync();

            statement = await database.PrepareStatementAsync(query);
            statement.BindTextParameterWithName("@name", "John");
            statement.BindTextParameterWithName("@surname", "Doe");

            await statement.StepAsync();
        }

        private async void OnGetDataClicked(object sender, RoutedEventArgs e)
        {
            Database database = new Database(ApplicationData.Current.LocalFolder, "people.db");

            await database.OpenAsync();

            string query = "SELECT * FROM PEOPLE";
            Statement statement = await database.PrepareStatementAsync(query);

            while (await statement.StepAsync())
            {
                MessageBox.Show(statement.GetTextAt(0) + " " + statement.GetTextAt(1));
            }
        }

        private async void OnGetSomeDataClicked(object sender, RoutedEventArgs e)
        {
            Database database = new Database(ApplicationData.Current.LocalFolder, "people.db");

            await database.OpenAsync();

            string query = "SELECT * FROM PEOPLE WHERE Name=@name";
            Statement statement = await database.PrepareStatementAsync(query);
            statement.BindTextParameterWithName("@name", "Matteo");

            while (await statement.StepAsync())
            {
                MessageBox.Show(statement.GetTextAt(0) + " " + statement.GetTextAt(1));
            }
        }


        private async void OnGetSomeDataWithColumnsPropertyClicked(object sender, RoutedEventArgs e)
        {
            Database database = new Database(ApplicationData.Current.LocalFolder, "people.db");

            await database.OpenAsync();

            string query = "SELECT * FROM PEOPLE";
            Statement statement = await database.PrepareStatementAsync(query);

            statement.EnableColumnsProperty();

            while (await statement.StepAsync())
            {
                MessageBox.Show(statement.Columns["Name"] + " " + statement.Columns["Surname"]);
            }
        }

        private async void OnInsertOrderClicked(object sender, RoutedEventArgs e)
        {
            Database database = new Database(ApplicationData.Current.LocalFolder, "people.db");

            await database.OpenAsync();

            string query = "INSERT INTO ORDERS(Description, Amount, PersonId) VALUES (@Description, @Amount, @PersonId)";
            Statement statement = await database.PrepareStatementAsync(query);
            statement.BindTextParameterWithName("@Description", "First order");
            statement.BindIntParameterWithName("@Amount", 200);
            statement.BindIntParameterWithName("@PersonId", 1);

            await statement.StepAsync();
        }

        private async void GetAllOrdersClicked(object sender, RoutedEventArgs e)
        {
            Database database = new Database(ApplicationData.Current.LocalFolder, "people.db");

            await database.OpenAsync();

            string query = "SELECT * FROM ORDERS INNER JOIN PEOPLE ON ORDERS.PersonId=PEOPLE.Id";

            Statement statement = await database.PrepareStatementAsync(query);
            statement.EnableColumnsProperty();

            while (await statement.StepAsync())
            {
                MessageBox.Show(string.Format("{0} by {1} {2}", statement.Columns["Description"],
                                              statement.Columns["Name"], statement.Columns["Surname"]));
            }

        }
    }
}