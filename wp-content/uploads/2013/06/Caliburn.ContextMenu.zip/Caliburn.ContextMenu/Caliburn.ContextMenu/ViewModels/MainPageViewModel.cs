using System.Collections.ObjectModel;
using Caliburn.ContextMenu.Entities;
using Caliburn.Micro;

namespace Caliburn.ContextMenu.ViewModels
{
    public class MainPageViewModel : Screen
    {
        private ObservableCollection<Person> persons;

        public ObservableCollection<Person> Persons
        {
            get { return persons; }
            set
            {
                persons = value;
                NotifyOfPropertyChange(() => Persons);
            }
        }

        public MainPageViewModel()
        {
            Persons = new ObservableCollection<Person>
                {
                    new Person
                        {
                            Name = "Matteo",
                            Surname = "Pagani"
                        },
                    new Person
                        {
                            Name = "John",
                            Surname = "Doe"
                        },
                    new Person
                        {
                            Name = "Mark",
                            Surname = "White"
                        }
                };
        }

        public void Delete(Person person)
        {
            Persons.Remove(person);
        }

    }
}