﻿using System;
using System.Diagnostics;
using Caliburn.Micro;
using Microsoft.Phone.Shell;

namespace CaliburnMicro.ViewModels
{
    public class MainPageViewModel: Screen
    {
        private string name;

        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                NotifyOfPropertyChange(() => Name);
            }
        }

        public void CreateTile()
        {
            ShellTileData tile = new StandardTileData
            {
                Title = "Test",
            };
            ShellTile.Create(new Uri("/Views/MainPage.xaml?Name=Ugo", UriKind.Relative), tile);
        }

        protected override void OnViewAttached(object view, object context)
        {
            base.OnViewAttached(view, context);
            Debug.WriteLine("OnViewAttached");
        }

        protected override void OnInitialize()
        {
            base.OnInitialize();
            Debug.WriteLine("OnInitialize");
        }

        protected override void OnViewReady(object view)
        {
            base.OnViewReady(view);
            Debug.WriteLine("OnViewReady");
        }

        protected override void OnActivate()
        {
            base.OnActivate();
            Debug.WriteLine("OnActivate:");
        }

        protected override void OnViewLoaded(object view)
        {
            base.OnViewLoaded(view);
            Debug.WriteLine("OnViewLoaded");
        }

        protected override void OnDeactivate(bool close)
        {
            base.OnDeactivate(close);
            Debug.WriteLine("OnDeactivate");
        }
    }
}
