﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Camera.Resources;
using Microsoft.Phone.Tasks;
using Microsoft.Xna.Framework.Media;
using Windows.Phone.Media.Capture;
using Windows.Storage;
using Microsoft.Devices;
using Size = Windows.Foundation.Size;

namespace Camera
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();


        }

        private PhotoCaptureDevice camera;

        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            Size resolution = PhotoCaptureDevice.GetAvailableCaptureResolutions(CameraSensorLocation.Back).First();
            camera = await PhotoCaptureDevice.OpenAsync(CameraSensorLocation.Back, resolution);
            video.SetSource(camera);
            previewTransform.Rotation = camera.SensorRotationInDegrees;
        }

        private async void OnTakePhotoClicked(object sender, RoutedEventArgs e)
        {
            CameraCaptureSequence cameraCaptureSequence = camera.CreateCaptureSequence(1);

            MemoryStream stream = new MemoryStream();
            cameraCaptureSequence.Frames[0].CaptureStream = stream.AsOutputStream();

            await camera.PrepareCaptureSequenceAsync(cameraCaptureSequence);
            await cameraCaptureSequence.StartCaptureAsync();

            stream.Seek(0, SeekOrigin.Begin);

            MediaLibrary library = new MediaLibrary();
            library.SavePictureToCameraRoll("picture1.jpg", stream);
        }
    }
}