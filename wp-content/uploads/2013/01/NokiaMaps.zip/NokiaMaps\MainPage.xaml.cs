﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Device.Location;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Maps.Controls;
using Microsoft.Phone.Maps.Services;
using Microsoft.Phone.Maps.Toolkit;
using Microsoft.Phone.Shell;
using NokiaMaps.Resources;
using Windows.Devices.Geolocation;
using GestureEventArgs = System.Windows.Input.GestureEventArgs;

namespace NokiaMaps
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            Loaded += MainPage_Loaded;
        }

        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            ObservableCollection<Restaurant> restaurants = new ObservableCollection<Restaurant>()
                                                               {
                                                                   new Restaurant
                                                                       {
                                                                           Coordinate =
                                                                               new GeoCoordinate(
                                                                               47.6050338745117,
                                                                               -122.334243774414),
                                                                           Address = "Ristorante 1"
                                                                       },
                                                                   new Restaurant()
                                                                       {
                                                                           Coordinate =
                                                                               new GeoCoordinate(
                                                                               47.6045697927475,
                                                                               -122.329885661602),
                                                                           Address = "Ristorante 2"
                                                                       },
                                                                   new Restaurant()
                                                                       {
                                                                           Coordinate =
                                                                               new GeoCoordinate(
                                                                               47.605712890625,
                                                                               -122.330268859863),
                                                                           Address = "Ristorante 3"
                                                                       },
                                                                   new Restaurant()
                                                                       {
                                                                           Coordinate =
                                                                               new GeoCoordinate(
                                                                               47.6015319824219,
                                                                               -122.335113525391),
                                                                           Address = "Ristorante 4"
                                                                       },
                                                                   new Restaurant()
                                                                       {
                                                                           Coordinate =
                                                                               new GeoCoordinate(
                                                                               47.6056594848633,
                                                                               -122.334243774414),
                                                                           Address = "Ristorante 5"
                                                                       }
                                                               };

            ObservableCollection<DependencyObject> children = MapExtensions.GetChildren(myMap);
            var obj =
                children.FirstOrDefault(x => x.GetType() == typeof (MapItemsControl)) as MapItemsControl;

            obj.ItemsSource = restaurants;
            myMap.SetView(new GeoCoordinate(47.6050338745117, -122.334243774414), 16);
        }

        //// Sample code for building a localized ApplicationBar
        ////private void BuildLocalizedApplicationBar()
        ////{
        ////    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        ////    ApplicationBar = new ApplicationBar();

        ////    // Create a new button and set the text value to the localized string from AppResources.
        ////    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        ////    appBarButton.Text = AppResources.AppBarButtonText;
        ////    ApplicationBar.Buttons.Add(appBarButton);

        ////    // Create a new menu item with the localized string from AppResources.
        ////    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        ////    ApplicationBar.MenuItems.Add(appBarMenuItem);
        ////}

        private void OnCenterButtonClicked(object sender, RoutedEventArgs e)
        {
            Geolocator geolocator = new Geolocator();


            //inizio la rilevazione


            geolocator.MovementThreshold = 100;
            geolocator.ReportInterval = 1000;
            geolocator.DesiredAccuracy = PositionAccuracy.High;

            geolocator.PositionChanged += geolocator_PositionChanged;
        }

        private void geolocator_PositionChanged(Geolocator sender, PositionChangedEventArgs args)
        {
            Dispatcher.BeginInvoke(() =>
                                       {
                                           Geocoordinate coordinate = args.Position.Coordinate;
                                           myMap.SetView(coordinate.ToGeoCoordinate(), 15, MapAnimationKind.Parabolic);
                                           UserLocationMarker marker = (UserLocationMarker)this.FindName("UserLocationMarker");
                                           marker.GeoCoordinate = coordinate.ToGeoCoordinate();
                                       });
        }

        private void OnAddShapeClicked(object sender, RoutedEventArgs e)
        {
            MapOverlay overlay = new MapOverlay
                                     {
                                         GeoCoordinate = myMap.Center,
                                         Content = new Ellipse
                                                       {
                                                           Fill = new SolidColorBrush(Colors.Blue),
                                                           Width = 40,
                                                           Height = 40
                                                       }
                                     };
            MapLayer layer = new MapLayer();
            layer.Add(overlay);

            myMap.Layers.Add(layer);

            Pushpin pushpin = (Pushpin) this.FindName("MyPushpin");
            pushpin.GeoCoordinate = new GeoCoordinate(45.3967, 009.3163);
        }

        private void MyPushpin_OnTap(object sender, GestureEventArgs e)
        {
            Pushpin pushpin = sender as Pushpin;
            MessageBox.Show(pushpin.Content.ToString());
        }
    }
}