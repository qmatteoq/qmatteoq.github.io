﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Caliburn.Micro;

namespace CaliburnMicro.ViewModels
{
    public class MainPageViewModel: PropertyChangedBase
    {
        private bool isEnabled;

        public bool IsEnabled
        {
            get { return isEnabled; }
            set
            {
                isEnabled = value;
                NotifyOfPropertyChange(() => IsEnabled);
                NotifyOfPropertyChange(() => CanShowName);
            }
        }

        public bool CanShowName
        {
            get { return IsEnabled; }
        }

        public void ShowName()
        {
            MessageBox.Show("Clicked");
        }
    }
}
