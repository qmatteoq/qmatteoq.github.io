﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using JumpList.Annotations;
using Telerik.Windows.Data;

namespace JumpList
{
    public class MainViewModel: INotifyPropertyChanged
    {
        private List<GenericGroupDescriptor<Person, string>> groupDescriptors;

        public List<GenericGroupDescriptor<Person, string>> GroupDescriptors
        {
            get { return groupDescriptors; }
            set
            {
                groupDescriptors = value;
                OnPropertyChanged("GroupDescriptors");
            }
        }

        private List<GenericSortDescriptor<Person, string>> sortDescriptors;

        public List<GenericSortDescriptor<Person, string>> SortDescriptors
        {
            get { return sortDescriptors; }
            set
            {
                sortDescriptors = value;
                OnPropertyChanged("SortDescriptors");
            }
        }

        private ObservableCollection<Person> people;

        public ObservableCollection<Person> People
        {
            get { return people; }
            set
            {
                people = value;
                OnPropertyChanged("People");
            }
        }

        public MainViewModel()
        {
            GroupDescriptors = new List<GenericGroupDescriptor<Person, string>>();
            SortDescriptors = new List<GenericSortDescriptor<Person, string>>();

            People = new ObservableCollection<Person>
                {
                    new Person
                        {
                            Name = "Matteo",
                            Surname = "Pagani",
                            City = "Como"
                        },
                    new Person
                        {
                            Name = "Ugo",
                            Surname = "Lattanzi",
                            City = "Milan"
                        },
                    new Person
                        {
                            Name = "Mario",
                            Surname = "Rossi",
                            City = "Milan"
                        }
                };

            GenericGroupDescriptor<Person, string> group = new GenericGroupDescriptor<Person, string>();
            group.SortMode = ListSortMode.Ascending;
            group.KeySelector = (person) =>
                {
                    return person.City;
                };

            GroupDescriptors.Add(group);

            GenericSortDescriptor<Person, string> sort = new GenericSortDescriptor<Person, string>();
            sort.SortMode = ListSortMode.Ascending;
            sort.KeySelector = person =>
                {
                    return person.Name;
                };

            SortDescriptors.Add(sort);
        }


        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
