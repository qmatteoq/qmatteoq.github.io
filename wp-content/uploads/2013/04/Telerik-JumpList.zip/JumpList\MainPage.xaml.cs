﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using JumpList.Resources;
using Telerik.Windows.Controls;
using Telerik.Windows.Data;

namespace JumpList
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        private void OnStandardApproachClicked(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Views/CodeBehind.xaml", UriKind.Relative));
        }

        private void OnMVVMClicked(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Views/MVVM.xaml", UriKind.Relative));
        }
    }
}