﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace Orientation.Views
{
    public partial class TranslateAnimation : PhoneApplicationPage
    {
        public TranslateAnimation()
        {
            InitializeComponent();
        }
    }
}