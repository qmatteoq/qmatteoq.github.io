﻿using System;
using System.Windows;
using Caliburn.Micro;
using Caliburn.Pivot.ViewModels;

namespace Caliburn.Pivot.ViewModels
{
    public class MainPageViewModel: Screen
    {
        private readonly INavigationService navigationService;

        public MainPageViewModel(INavigationService navigationService)
        {
            this.navigationService = navigationService;
          
        }

        public void GoToPivot()
        {
            navigationService.UriFor<PivotViewModel>().Navigate();
        }
    }
}
