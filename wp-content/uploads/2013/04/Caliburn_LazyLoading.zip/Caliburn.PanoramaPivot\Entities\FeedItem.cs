﻿using System;

namespace Caliburn.Pivot.Entities
{
    public class FeedItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
    }
}
