﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Caliburn.Micro;
using Caliburn.Pivot.Entities;
using Caliburn.Pivot.Helpers;

namespace Caliburn.Pivot.ViewModels
{
    public class PivotItem3ViewModel : Screen
    {
        public PivotItem3ViewModel()
        {
            DisplayName = "Third pivot";
        }

        protected override async void OnActivate()
        {
            base.OnActivate();
            WebClient client = new WebClient();
            string result = await client.DownloadStringTaskAsync("http://feeds.feedburner.com/override/tostring/it");
            IEnumerable<FeedItem> feedItems = RssParser.ParseXml(result);

            FeedItems = feedItems.ToList();
        }

        private List<FeedItem> _feedItems;

        public List<FeedItem> FeedItems
        {
            get { return _feedItems; }
            set
            {
                _feedItems = value;
                NotifyOfPropertyChange(() => FeedItems);
            }
        }
    }
}
