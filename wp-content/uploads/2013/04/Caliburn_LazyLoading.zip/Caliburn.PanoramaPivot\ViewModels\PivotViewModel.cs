﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Caliburn.Micro;

namespace Caliburn.Pivot.ViewModels
{
    public class PivotViewModel: Conductor<IScreen>.Collection.OneActive
    {
        private readonly PivotItem1ViewModel item1;
        private readonly PivotItem2ViewModel item2;
        private readonly PivotItem3ViewModel item3;

        public PivotViewModel(PivotItem1ViewModel item1, PivotItem2ViewModel item2, PivotItem3ViewModel item3)
        {
            this.item1 = item1;
            this.item2 = item2;
            this.item3 = item3;
        }

        protected override void OnInitialize()
        {
            base.OnInitialize();

            Items.Add(item1);
            Items.Add(item2);
            Items.Add(item3);

            ActivateItem(item1);
        }
    }
}
