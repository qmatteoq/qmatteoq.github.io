﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Telerik.Windows.Controls;
using Telerik.Windows.Data;

namespace JumpList.Views
{
    public partial class StandardCodeBehind : PhoneApplicationPage
    {
        public StandardCodeBehind()
        {
            InitializeComponent();
            ObservableCollection<Person> people = new ObservableCollection<Person>
                {
                    new Person
                        {
                            Name = "Matteo",
                            Surname = "Pagani",
                            City = "Como"
                        },
                    new Person
                        {
                            Name = "Ugo",
                            Surname = "Lattanzi",
                            City = "Milan"
                        },
                    new Person
                        {
                            Name = "Mario",
                            Surname = "Rossi",
                            City = "Milan"
                        }
                };

            People.ItemsSource = people;

            GenericGroupDescriptor<Person, string> group = new GenericGroupDescriptor<Person, string>();
            group.SortMode = ListSortMode.Ascending;
            group.KeySelector = (person) =>
            {
                return person.City;
            };

            GenericSortDescriptor<Person, string> sort = new GenericSortDescriptor<Person, string>();
            sort.SortMode = ListSortMode.Ascending;
            sort.KeySelector = person =>
            {
                return person.Name;
            };

            People.SortDescriptors.Add(sort);
            People.GroupDescriptors.Add(group);
        }

     
    }
}