﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using JumpList.Annotations;

namespace JumpList.ViewModels
{
    public class MultiSelectViewModel : ViewModelBase
    {
        private ObservableCollection<Person> people;

        public ObservableCollection<Person> People
        {
            get { return people; }
            set
            {
                people = value;
                RaisePropertyChanged("People");
            }
        }

        private ObservableCollection<Person> itemsToDelete;

        public ObservableCollection<Person> ItemsToDelete
        {
            get { return itemsToDelete; }
            set
            {
                itemsToDelete = value;
                RaisePropertyChanged("ItemsToDelete");
            }
        }


        public MultiSelectViewModel()
        {
            People = new ObservableCollection<Person>
                {
                    new Person
                        {
                            Name = "Matteo",
                            Surname = "Pagani",
                            City = "Como"
                        },
                    new Person
                        {
                            Name = "Ugo",
                            Surname = "Lattanzi",
                            City = "Milan"
                        },
                    new Person
                        {
                            Name = "Mario",
                            Surname = "Rossi",
                            City = "Milan"
                        }
                };

            ItemsToDelete = new ObservableCollection<Person>();
        }

        private RelayCommand showCount;

        public RelayCommand ShowCount
        {
            get
            {
                if (showCount == null)
                {
                    showCount = new RelayCommand(() =>
                                                     {
                                                         MessageBox.Show(ItemsToDelete.Count.ToString());
                                                     });
                }
                return showCount;
            }
        }
    }
}
