﻿using System.Windows;
using System.Windows.Interactivity;
using JumpList;
using JumpList.ViewModels;
using Telerik.Windows.Controls;

//using Microsoft.Expression.Interactivity.Core;

namespace SpeakerTimer.Assets.Behaviors
{
    public class AddoToCheckedItemBehavior : Behavior<RadJumpList>
    {
        public AddoToCheckedItemBehavior() { }

        protected override void OnAttached()
        {
            base.OnAttached();
            this.AssociatedObject.ItemCheckedStateChanged += AssociatedObject_ItemCheckedStateChanged;
        }

        void AssociatedObject_ItemCheckedStateChanged(object sender, ItemCheckedStateChangedEventArgs e)
        {
            var viewModel = ((FrameworkElement)sender).DataContext as MultiSelectViewModel;
            if (viewModel == null) return;
            if (e.IsChecked)
            {
                viewModel.ItemsToDelete.Add(((Telerik.Windows.Data.IDataSourceItem)e.Item).Value as Person);
            }
            else { viewModel.ItemsToDelete.Remove(((Telerik.Windows.Data.IDataSourceItem)e.Item).Value as Person); }
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();
            this.AssociatedObject.ItemCheckedStateChanged -= AssociatedObject_ItemCheckedStateChanged;
        }
    }
}