﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using ShareData.Launcher.Resources;
using Windows.Storage;
using ShareData.Launcher.Helpers;

namespace ShareData.Launcher
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        private async void OnOpenFileButtonClicked(object sender, RoutedEventArgs e)
        {
            StorageFile file = await ApplicationData.Current.LocalFolder.GetFileAsync("rss.log");
            Windows.System.Launcher.LaunchFileAsync(file);
        }

        private async void OnCreateFileButtonClicked(object sender, RoutedEventArgs e)
        {
            WebClient client = new WebClient();
            string result = await client.DownloadStringTaskAsync("http://feeds.feedburner.com/qmatteoq_eng");

            await result.WriteToFile("rss.log");
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Windows.System.Launcher.LaunchUriAsync(new Uri("qmatteoq:NewProducts"));
        }

        private async void Button_Click_4(object sender, RoutedEventArgs e)
        {
            WebClient client = new WebClient();
            string result = await client.DownloadStringTaskAsync("http://feeds.feedburner.com/qmatteoq");

            await result.WriteToFile("log.docx");

            StorageFile file = await ApplicationData.Current.LocalFolder.GetFileAsync("log.docx");

            Windows.System.Launcher.LaunchFileAsync(file);
        }


        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}
    }
}