﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using SQLite;
using SqlLiteWP8.Model;

namespace SqlLiteWP8
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            CreateDatabase();

            ///Sample code to call helper function to localize the ApplicationBar
            //BuildApplicationBar();
        }

        private async void CreateDatabase()
        {
            SQLiteAsyncConnection conn = new SQLiteAsyncConnection("people");
            await conn.CreateTableAsync<Person>();
        }

        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            SQLiteAsyncConnection conn = new SQLiteAsyncConnection("people");

            Person person = new Person
            {
                Name = "Matteo",
                Surname = "Pagani"
            };

            await conn.InsertAsync(person);
        }

        private async void Button_Click_2(object sender, RoutedEventArgs e)
        {
            SQLiteAsyncConnection conn = new SQLiteAsyncConnection("people");

            var query = conn.Table<Person>().Where(x => x.Name == "Matteo");
            var result = await query.ToListAsync();
            foreach (var item in result)
            {
                Debug.WriteLine(string.Format("{0}: {1} {2}", item.Id, item.Name, item.Surname));
            }
        }
    }
}