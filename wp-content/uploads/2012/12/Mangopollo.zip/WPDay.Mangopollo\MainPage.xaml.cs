﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Mangopollo;
using Mangopollo.Tasks;
using Mangopollo.Tiles;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace WPDay.MangopolloDemo
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnCreateAppointmentClick(object sender, RoutedEventArgs e)
        {
            if (Utils.IsWP8)
            {
                SaveAppointmentTask task = new SaveAppointmentTask();
                task.Subject = "Windows Phone Developer Day";
                task.StartTime = new DateTime(2012, 12, 5);
                task.IsAllDayEvent = true;
                task.Show();
            }
            else
            {
                MessageBox.Show("This is Windows Phone 7!");
            }
        }

        private void OnCreateWideTileClick(object sender, RoutedEventArgs e)
        {
            if (Utils.IsWP8)
            {
                var tile = new IconicTileData
                {
                    Title = "WP Day",
                    Count = 8,
                    BackgroundColor = Colors.Transparent,
                    IconImage = new Uri("/Assets/Tiles/IconicTileMediumLarge.png", UriKind.Relative),
                    SmallIconImage = new Uri("/Assets/Tiles/IconicTileSmall.png", UriKind.Relative),
                    WideContent1 = "WP Developer Day",
                    WideContent2 = "use Windows Phone 8 features",
                    WideContent3 = "on Windows Phone 7 apps"
                }.ToShellTileData();

                ShellTileExt.Create(new Uri("/MainPage.xaml?Id=5", UriKind.Relative), tile, true);
            }
            else
            {
                MessageBox.Show("This is Windows Phone 7");
            }
        }

        private void OnUpdateTileClick(object sender, RoutedEventArgs e)
        {
            if (Utils.IsWP8)
            {
                IconicTileData tile = new IconicTileData
                                          {
                                              WideContent1 = "This is the new content",
                                              WideContent2 = "The tile has been updated",
                                              WideContent3 = "with success"
                                          };

                Uri navigationUri = new Uri("/MainPage.xaml?Id=5", UriKind.Relative);
                ShellTile.ActiveTiles.FirstOrDefault(x => x.NavigationUri == navigationUri).Update();
            }
        }
    }
}